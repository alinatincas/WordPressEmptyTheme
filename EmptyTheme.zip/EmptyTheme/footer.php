            <div class="row">
                <div class="col-md-12">
                    <?php wp_footer(); ?> <!-- get the wp footer -->
                </div><!-- /.col -->
            </div><!-- /.row -->
        </div><!-- /.container -->
    </body>
</html>