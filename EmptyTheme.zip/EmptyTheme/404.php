<?php get_header(); ?>
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <h1>Beklager, siden blev ikke fundet!</h1> <!--Sorry, page not found!-->
                <h3>Det ser ud til, at der ikke blev fundet noget på denne side.</h3> 
                <h3>Prøv at gå tilbage eller kontrollere andre links fra menuen!</h3> 
            </div>
        </div>
    </div>
<?php get_footer(); ?>